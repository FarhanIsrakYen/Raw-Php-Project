<!DOCTYPE html>
<html>
<head>
	<title>BPL-Ticket Management System</title>
	<link rel="stylesheet" type="text/css" href="ticketInfo.css">
</head>
<body>
<a class="logo" href="ticketInfo.php"><img src="./logo.jpg"></a>
<div class="header">
<ul>
	<li class="title"><a href="loggedHome.php"><span class="title">Bangladesh Premier League</span></a></li>
	<li></li>
	<li></li>
	<li></li>
	<li></li>
	<li></li>
	<li></li>
	<li></li>
	<li></li>
	<li></li>
	<li></li>
	<li></li>
	<li></li>
	<li></li>
	<li></li>
	<li></li>
	<li></li>
	<li><a href="loggedHome.php"><span class="tab">Back</span></a></li>
</ul>
<marquee class="banner">Check out the seat no. carefully!!!</marquee>
<br><br><br>
</div><br><br><br>
<div class="ticket">
<p ><h2 style="color:#b30000;">	Price List for the tickets of the matches in - Sher e Bangla Stadium:</h2><br>

	Grand-stand: 2000 Taka   (Seat no.- G00-G30)<br>
	Club House: 500 Taka     (Seat no.- C000-C100)<br>
	VIP Stand: 500 Taka      (Seat no.- V000-V500)<br>
	Northern Stand: 300 Taka  (Seat no.- N0000-N1000)<br>
	Southern Stand: 300 Taka  (Seat no.- S0000-S1000)<br>
	Eastern Stand: 200 Taka   (Seat no.- E00000-E10000)</p>
<p><h2 style="color:#009933;">	Price List for the tickets of the matches in -Sylhet International Cricket Stadium:</h2><br>

	Grand-stand: 2000 Taka(Seat no.- G00-G30)<br>
	Club House: 500 Taka(Seat no.- C000-C100)<br>
	Green Hill Area: 400 Taka(Seat no.- GH000-GH500)<br>
	Western Stand:  300 Taka(Seat no.- W0000-W1000)<br>
	Eastern Stand: 200 Taka(Seat no.- E00000-E10000)</p>
<p><h2 style="color:#ffff99;">	Price List for the tickets of the matches in - Zahur Ahmed Chowdhury Cricket Stadium:</h2><br>

	Grand-stand: 2000 Taka(Seat no.- G00-G30)<br>
	Club House: 500 Taka(Seat no.- C000-C100)<br>
	Western Stand: 300 Taka(Seat no.- W0000-W1000)<br>
	Eastern Stand: 200 Taka	(Seat no.- E00000-E10000)</p>		
	
</div>
</body>
</html>