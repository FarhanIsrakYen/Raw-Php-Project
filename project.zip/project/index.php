<!DOCTYPE html>
<html>
<head>
	<title>BPL-Ticket Management System</title>
	<link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>
<div class="header">
	<button class="b1"><a href="home.php">Enter into <br>BangladeshPremierLeague.com</a></button>
</div>
</body>
</html>