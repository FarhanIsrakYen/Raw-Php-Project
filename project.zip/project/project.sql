-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 24, 2017 at 07:57 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `gameinfo`
--

CREATE TABLE `gameinfo` (
  `gameNo` int(11) NOT NULL,
  `HomeTeam` varchar(55) NOT NULL,
  `AwayTeam` varchar(55) NOT NULL,
  `Venue` varchar(55) NOT NULL,
  `matchdate` date NOT NULL,
  `day` varchar(55) NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gameinfo`
--

INSERT INTO `gameinfo` (`gameNo`, `HomeTeam`, `AwayTeam`, `Venue`, `matchdate`, `day`, `time`) VALUES
(4, 'Comilla Victorians', 'Rangpur Riders', 'Chittagong', '2017-12-29', 'Friday', '12:30:00'),
(6, 'Khulna Titans', 'Rangpur Riders', 'Sylhet', '2017-12-18', 'Monday', '19:30:00'),
(8, 'Sylhet Sixers', 'Khulna Titans', 'Zahur Ahmed Chowdhury Cricket Stadium', '2017-12-05', 'Sunday', '21:04:00'),
(9, 'Sylhet Sixers', 'Khulna Titans', 'Zahur Ahmed Chowdhury Cricket Stadium', '2017-12-05', 'Sunday', '21:04:00'),
(10, 'Sylhet Sixers', 'Dhaka Dynamites', 'Sher-e-Bangla Stadium', '2017-12-15', 'Thursday', '16:30:00'),
(11, 'Khulna Titans', 'Sylhet Sixers', 'Sylhet International Cricket Stadium', '2017-12-14', 'Sunday', '14:02:00'),
(12, 'Dhaka Dynamites', 'Khulna Titans', 'Sher-e-Bangla Stadium', '2018-01-02', 'Saturday', '19:56:00');

-- --------------------------------------------------------

--
-- Table structure for table `ticketinfo`
--

CREATE TABLE `ticketinfo` (
  `tid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `gameNo` int(11) NOT NULL,
  `seatNo` varchar(55) NOT NULL,
  `name` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticketinfo`
--

INSERT INTO `ticketinfo` (`tid`, `uid`, `gameNo`, `seatNo`, `name`) VALUES
(15, 19, 4, 'G01', 'Farhan Israk'),
(20, 19, 4, 'G11', 'Farhan Israk'),
(21, 19, 3, 'G01', 'Farhan Israk');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `FullName` varchar(55) NOT NULL,
  `UserName` varchar(20) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `FullName`, `UserName`, `password`, `email`) VALUES
(27, 'Farhan Israk Yen', 'farhan1212', '123456', 'farhan@gmail.com'),
(28, 'Farhan Israk', 'admin', 'admin', 'admin@gmail.com'),
(29, 'Farhan Israk', 'Farhan', '12345', 'hydro.toluyn@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gameinfo`
--
ALTER TABLE `gameinfo`
  ADD PRIMARY KEY (`gameNo`);

--
-- Indexes for table `ticketinfo`
--
ALTER TABLE `ticketinfo`
  ADD PRIMARY KEY (`tid`),
  ADD UNIQUE KEY `gameNo` (`gameNo`,`seatNo`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `UserName` (`UserName`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gameinfo`
--
ALTER TABLE `gameinfo`
  MODIFY `gameNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `ticketinfo`
--
ALTER TABLE `ticketinfo`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
