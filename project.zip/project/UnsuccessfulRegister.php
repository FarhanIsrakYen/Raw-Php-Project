<!DOCTYPE html>
<html>
<head>
	<title>Log In</title>
	<link rel="stylesheet" type="text/css" href="home.css">
	<link rel="stylesheet" type="text/css" href="login.css">
</head>
<body>
<a class="logo" href="home.php"><img src="./logo.jpg"></a>

<div class="header">
<ul>
	<li class="title"><a href="home.php"><span class="title">Ticket Management System</span></a></li>
	<li></li>
	<li></li>
	<li></li>
	<li></li>
	<li></li>
	<li></li>
	<li></li>
	<li></li>
	<li></li>
	<li></li>
	
	<li><a href="signup.php"><span class="tab">Sign Up</span></a></li>
	<li><a href="login.php"><span class="tab">Log In</span></a></li>
</ul>
<br><br><br>
</div>

<div class="container">
	The User Name or Email you entered already exists!!<br> Use other user name or email!!			
	
</div>

</body>
</html>